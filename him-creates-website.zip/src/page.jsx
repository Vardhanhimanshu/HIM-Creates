"use client";
import React, { useState } from "react";
import { Youtube, Moon, Sun } from "lucide-react";

export default function HomePage() {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <main className={darkMode ? "min-h-screen bg-gray-900 text-white p-6" : "min-h-screen bg-gray-50 text-gray-800 p-6"}>
      <nav className="flex justify-between items-center py-4 border-b">
        <h1 className="text-2xl font-bold">HIM Creates</h1>
        <div className="space-x-4">
          <button className="bg-transparent hover:underline">Home</button>
          <button className="bg-transparent hover:underline">Notes</button>
          <button className="bg-transparent hover:underline">Presentations</button>
          <button className="bg-transparent hover:underline">Videos</button>
          <button className="bg-transparent hover:underline">Contact</button>
          <button onClick={() => setDarkMode(!darkMode)}>
            {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      <section className="text-center py-10">
        <h2 className="text-4xl font-bold mb-4">Welcome to HIM Creates Channel</h2>
        <p className="text-lg">Education | Presentations | Handwritten Notes</p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
        <div className="border p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-2">Handwritten Notes</h2>
          <p className="mb-4">Download high-quality handwritten notes for your studies.</p>
          <a href="#" className="text-blue-500 hover:underline">View Notes</a>
        </div>

        <div className="border p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-2">Presentations</h2>
          <p className="mb-4">Explore engaging presentations on important topics.</p>
          <a href="#" className="text-blue-500 hover:underline">View Presentations</a>
        </div>

        <div className="border p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-2">YouTube Videos</h2>
          <p className="mb-4">Watch our educational videos directly from YouTube.</p>
          <a href="https://www.youtube.com/@himcreates" target="_blank" className="text-blue-500 flex items-center gap-2 hover:underline">
            <Youtube className="w-5 h-5" /> Visit Channel
          </a>
        </div>
      </section>

      <footer className="text-center mt-20 text-sm text-gray-500 dark:text-gray-400">
        © 2025 HIM Creates Channel. All rights reserved.
      </footer>
    </main>
  );
}
